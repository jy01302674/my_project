/*
Navicat MySQL Data Transfer

Source Server         : 本地数据库连接
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : ci_learn

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-12-17 11:03:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sh_user
-- ----------------------------
DROP TABLE IF EXISTS `sh_user`;
CREATE TABLE `sh_user` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` char(32) DEFAULT NULL,
  `email` varchar(40) DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sh_user
-- ----------------------------
INSERT INTO `sh_user` VALUES ('1', 'superadmin', 'admin88', 'admin@163.com');
INSERT INTO `sh_user` VALUES ('2', 'caoyang', 'admin88', 'gogery@163.com');
INSERT INTO `sh_user` VALUES ('3', 'mark', 'markadmin88', 'mark@sina.com');
