<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <script src="../jquery-2.0.3.js"></script>
  <script src="./sha-512.js"></script>
  <script>
    var time = parseInt( (new Date()-0)/1000 );
    var appid = 10001;
    var strnu = rand(); 
    var appsecret = '0a989ebc4a77b56a6e2bb7b19d995d185ce44090c13e2984b7ecc6d446d4b61ea9991b76a4c2f04b1b4d244841449454'; 
    password = [time,strnu,appid,appsecret].join('');
    var sign = hex_sha512( password ); // sha512加密算法
    data = {
      'id' : 1,
      'appid': appid,                // 应用ID
      'strnu': strnu,
      'time' : time, // 请求时间戳
      'sign' : sign,                       // sign 加密算法: sha512([time,strnu,appid,appsecret])
    };
    $.post('api.php',data,function(){
    });

    function rand(){
      return parseInt( Math.random()*999999 );
    }
    console.log( rand() );
  </script>
</body>
</html>