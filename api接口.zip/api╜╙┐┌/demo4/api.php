<?php
  header('Content-Type:text/html;charset=utf-8');

  if( !isset( $_POST['appid'] ) || !isset( $_POST['time'] ) ){
    json(['code'=>101,'message'=>'缺少appid参数！']);
  }

  $db = new pdo('mysql:dbname=test;host=127.0.0.1','root','root');

  // 验证appid
  $appid = $_POST['appid'];
  $sql = "select * from `api` where appid = '$appid'";
  $data = $db->query($sql)->fetch(PDO::FETCH_ASSOC);
  $appsecret = $data['appsecret'];
  
  $time = $_POST['time'];

  if( time() - 10 > $time ){
    json(['code'=>102,'message'=>'请求超时！']);
  }

  $strnu = $_POST['strnu'];

  $params = implode( [$time,$strnu,$appid,$appsecret] );
  if( $_POST['sign'] != hash('sha512',$params) ){
    json(['code'=>103,'message'=>'sign验证失败！']);
  }

  if( isset($_POST['id']) ){
    $id = $_POST['id'];
    $sql = "select * from `api` where id=" . $id;
    $data = $db->query($sql)->fetch(PDO::FETCH_ASSOC);
    json($data); 
  }

  function json($data){
    echo json_encode($data);die;
  }