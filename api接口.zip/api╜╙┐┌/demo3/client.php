<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <p>3101373052289 韵达</p>
  <p>667639416219 天天</p>
  <select name="com">
    <option value="tiantian">天天快递</option>
    <option value="huitongkuaidi">百世汇通</option>
    <option value="shunfeng">顺风快递</option>
    <option value="yunda">韵达快递</option>
  </select>
  <input type="nu" placeholder="请输入您要查询的快递单号">
  <button id="btn">点击查询</button>
  <iframe id="kuaidi" name="kuaidi100" style="display:none;" src="" width="600" height="380" marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" scrolling="no"></iframe>
  <script src="../jquery-2.0.3.js"></script>
  <script>
    $('#btn').on('click',function(){
      data = {
        'com':  $('select[name=com]').val(),
        'nu' :  $('input[type=nu]').val(),
      };
      $.get('api.php',data,function( msg ){
        console.log( msg );
        $('#kuaidi').attr('src',msg);
        $('#kuaidi').show();
      });
    });
  </script>
</body>
</html>