<?php
  header('Content-Type:text/html;charset=utf-8');
  if( isset($_GET['com']) && isset($_GET['nu']) ){
    $com = $_GET['com'];
    $nu = $_GET['nu'];
  }
  $url = file_get_contents("http://www.kuaidi100.com/applyurl?key=e46ad5cbf651c868&com=$com&nu=$nu");
  echo $url;
