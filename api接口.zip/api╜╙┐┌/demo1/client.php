<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <script src="jquery-2.0.3.js"></script>
  <script>
    data = {
      'id' : 1,
    };
    $.post('api.php',data,function(){

    });
  </script>
</body>
</html>