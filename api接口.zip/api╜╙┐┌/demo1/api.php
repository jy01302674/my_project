<?php
  header('Content-Type:text/html;charset=utf-8');
  $db = new pdo('mysql:dbname=boxuegu;host=127.0.0.1','root','root');
  if( isset($_POST['id']) ){
    $id = $_POST['id'];
    $sql = "select * from `edu_admin` where id=" . $id;
    $data = $db->query($sql)->fetch(PDO::FETCH_ASSOC);
    echo json($data); 
  }

  function json($data){
    return json_encode($data);
  }