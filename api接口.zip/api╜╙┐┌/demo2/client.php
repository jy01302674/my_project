<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>天气接口</title>
</head>
<body>
  <button id="btn">点击</button>
  <script src="jquery-2.0.3.js"></script>
  <script>
    $('#btn').on('click',function(){
      var script = document.createElement('script');
      script.src = 'http://weather.123.duba.net/static/weather_info/101280101.html';
      document.head.appendChild(script);
    });
    function weather_callback(msg){
      console.log( msg );
    }

  </script>
</body>
</html>